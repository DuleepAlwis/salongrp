CREATE VIEW teadata AS
  SELECT
    `school`.`teacher`.`tid`   AS `tid`,
    `school`.`teacher`.`tname` AS `tname`,
    `school`.`teacher`.`email` AS `email`,
    `school`.`teacher`.`tpno`  AS `tpno`
  FROM `school`.`teacher`;

