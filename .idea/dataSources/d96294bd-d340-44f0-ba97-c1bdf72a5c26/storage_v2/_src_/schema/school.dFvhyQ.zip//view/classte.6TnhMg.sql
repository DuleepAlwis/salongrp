CREATE VIEW classte AS
  SELECT
    `school`.`class`.`cid`      AS `cid`,
    `school`.`class`.`location` AS `location`,
    `school`.`class`.`tid`      AS `tid`,
    `school`.`teacher`.`tname`  AS `tname`
  FROM `school`.`class`
    JOIN `school`.`teacher`
  WHERE (`school`.`teacher`.`tid` = `school`.`class`.`tid`);

