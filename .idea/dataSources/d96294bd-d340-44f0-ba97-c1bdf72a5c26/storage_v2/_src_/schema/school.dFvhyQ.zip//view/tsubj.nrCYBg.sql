CREATE VIEW tsubj AS
  SELECT
    `school`.`teacher_sub`.`tid`   AS `tid`,
    `school`.`teacher_sub`.`subid` AS `subid`,
    `school`.`teacher`.`tname`     AS `tname`,
    `school`.`subjects`.`subname`  AS `subname`
  FROM `school`.`teacher_sub`
    JOIN `school`.`teacher`
    JOIN `school`.`subjects`
  WHERE ((`school`.`teacher_sub`.`tid` = `school`.`teacher`.`tid`) AND
         (`school`.`subjects`.`subid` = `school`.`teacher_sub`.`subid`));

