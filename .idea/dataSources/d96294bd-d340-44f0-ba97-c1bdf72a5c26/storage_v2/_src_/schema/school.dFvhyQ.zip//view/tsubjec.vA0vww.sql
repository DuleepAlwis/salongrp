CREATE VIEW tsubjec AS
  SELECT
    `school`.`subjects`.`subid`   AS `subid`,
    `school`.`subjects`.`subname` AS `subname`,
    `tsubj`.`tid`                 AS `tid`,
    `tsubj`.`tname`               AS `tname`
  FROM (`school`.`subjects`
    LEFT JOIN `school`.`tsubj` ON ((`school`.`subjects`.`subid` = `tsubj`.`subid`)));

